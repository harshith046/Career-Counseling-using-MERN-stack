const mongoose = require('mongoose');

// Encode special characters in the password
const url = "YOUR MONGODB-ATLAS URL GOES HERE";

const connectToMongo = async () => {
    await mongoose.connect(url);
    console.log("connected");
};

module.exports = connectToMongo;
