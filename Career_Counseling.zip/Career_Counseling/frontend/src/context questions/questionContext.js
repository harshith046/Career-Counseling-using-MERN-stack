import {createContext} from "react"

const questionContext = createContext();

export default questionContext;