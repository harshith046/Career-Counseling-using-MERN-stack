import {createContext} from "react"

const answerContext = createContext();

export default answerContext;