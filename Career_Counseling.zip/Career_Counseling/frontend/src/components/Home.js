import React from 'react'

const Home = () => {
  return (
    <div>
      Hiiii
     {/* <button class="home_login_b" */}
    </div>
  )
}

export default Home
